ROS2 HUMBLE
===========

Bienvenido a la documentación oficial de la capacitación de ROS2 Humble.

Esta serie de códigos ha sido compilado y desarrollado por AvigTech.

.. image:: _static/avigtech/logo.png
   :alt: AvigtechLogo
   :align: center

Contenido
=========

.. toctree::
   :maxdepth: 2
   :caption: Módulos

   documentos/tema_0/intro
   documentos/tema_1/instalacion
   documentos/tema_1/maquina_virtual
   documentos/tema_1/instalacionROS2
   documentos/tema_2/conceptos_basicos
   documentos/tema_2/tutoriales
   documentos/tema_3/dispositivos
   documentos/tema_4/visualizacion_datos
